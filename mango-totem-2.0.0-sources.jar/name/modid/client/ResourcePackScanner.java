package name.modid.client;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import net.minecraft.class_3288;
import net.minecraft.class_7367;

/**
 * Looks through the player's installed resource packs for the vanilla
 * totem-of-undying texture, so they can pick one of their own packs as
 * their custom totem instead of a fixed built-in list.
 *
 * VERIFY: the Pack / PackResources APIs used here (how you get from a
 * "known pack" to its opened PackResources, and the exact method to read a
 * single file out of it) have been reshuffled a few times across Minecraft
 * versions. If this file doesn't compile as-is, open `Pack` and
 * `PackResources` in your IDE (after ./gradlew genSources) -- you're
 * looking for: (1) how to iterate the packs the game knows about, (2) how
 * to open one into a PackResources, and (3) the method on PackResources
 * that returns an input stream for a namespaced path like
 * "minecraft:textures/item/totem_of_undying.png". The rest of the pipeline
 * (read bytes -> decode -> register texture) does not need to change.
 */
public final class ResourcePackScanner {

    public record FoundPack(String displayName, byte[] pngData) {}

    public static List<FoundPack> scan() {
        List<FoundPack> results = new ArrayList<>();
        class_310 client = class_310.method_1551();

        for (class_3288 pack : client.method_1520().method_14441()) {
            if (pack.method_14463().equals("vanilla") || pack.method_14463().equals("fabric")) {
                continue; // everyone already has the vanilla texture
            }

            try (class_3262 resources = pack.method_14458()) {
                if (resources == null) continue;

                class_7367<InputStream> supplier = resources.method_14405(
                        class_3264.field_14188,
                        class_2960.method_60655("minecraft", "textures/item/totem_of_undying.png")
                );
                if (supplier == null) continue;

                try (InputStream stream = supplier.get()) {
                    byte[] bytes = stream.readAllBytes();
                    results.add(new FoundPack(pack.method_14457().getString(), bytes));
                }
            } catch (IOException ignored) {
                // Pack didn't have the file, or couldn't be opened -- just skip it.
            }
        }

        return results;
    }

    private ResourcePackScanner() {}
}
