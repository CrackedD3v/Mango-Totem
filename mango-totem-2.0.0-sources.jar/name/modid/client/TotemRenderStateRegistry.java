package name.modid.client;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.class_10444;
import net.minecraft.class_2960;

public final class TotemRenderStateRegistry {
    private static final Map<class_10444, class_2960> SKINS = new WeakHashMap<>();

    public static synchronized void remember(class_10444 state, class_2960 skin) {
        if (skin == null) {
            SKINS.remove(state);
        } else {
            SKINS.put(state, skin);
        }
    }

    public static synchronized class_2960 get(class_10444 state) {
        return SKINS.get(state);
    }

    private TotemRenderStateRegistry() {}
}