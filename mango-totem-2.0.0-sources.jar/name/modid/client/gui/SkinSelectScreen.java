package name.modid.client.gui;

import name.modid.client.MangoTotemClient;
import name.modid.client.ResourcePackScanner;
import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.List;

/**
 * Lists the player's installed resource packs that contain a totem texture
 * override. Clicking one sends that pack's totem PNG bytes to the server,
 * which relays it to everyone else with the mod.
 */
public class SkinSelectScreen extends class_437 {

    private List<ResourcePackScanner.FoundPack> foundPacks;

    public SkinSelectScreen() {
        super(class_2561.method_43471("screen.mango-totem.select_skin"));
    }

    @Override
    protected void method_25426() {
        this.foundPacks = ResourcePackScanner.scan();

        int buttonWidth = 220;
        int x = this.field_22789 / 2 - buttonWidth / 2;
        int totalRows = foundPacks.size() + 3;
        int y = this.field_22790 / 2 - (totalRows * 24) / 2;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Enchanted color: cyan"), button -> {
                int next = MangoTotemClient.enchantedColor == 0xFFFF00
                    ? 0xFF00FF
                    : MangoTotemClient.enchantedColor == 0xFF00FF ? 0x00AAFF : 0xFFFF00;
                MangoTotemClient.setEnchantedColor(next);
                button.method_25355(class_2561.method_43470(next == 0xFFFF00
                    ? "Enchanted color: cyan"
                    : next == 0xFF00FF ? "Enchanted color: magenta" : "Enchanted color: gold"));
            })
            .method_46434(x, y, buttonWidth, 20)
            .method_46431());
        y += 24;

        if (foundPacks.isEmpty()) {
            this.method_37063(class_4185.method_46430(
                            class_2561.method_43470("No resource packs with a custom totem found"),
                            button -> {})
                    .method_46434(x, y, buttonWidth, 20)
                    .method_46431());
            y += 24;
        }

        for (ResourcePackScanner.FoundPack pack : foundPacks) {
            this.method_37063(class_4185.method_46430(
                            class_2561.method_43470("Use: " + pack.displayName()),
                            button -> {
                                MangoTotemClient.selectSkin(pack.pngData());
                                this.method_25419();
                            })
                    .method_46434(x, y, buttonWidth, 20)
                    .method_46431());
            y += 24;
        }

        this.method_37063(class_4185.method_46430(
                        class_2561.method_43470("Clear (use vanilla totem)"),
                        button -> {
                            MangoTotemClient.selectSkin(null);
                            this.method_25419();
                        })
                .method_46434(x, y, buttonWidth, 20)
                .method_46431());
        y += 24;

        this.method_37063(class_4185.method_46430(class_2561.method_43471("gui.cancel"),
                        button -> this.method_25419())
                .method_46434(x, y, buttonWidth, 20)
                .method_46431());
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
