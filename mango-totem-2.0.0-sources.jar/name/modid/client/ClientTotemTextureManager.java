package name.modid.client;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

/**
 * Holds a dynamically-registered GPU texture per player who has a custom
 * totem set, decoded from the PNG bytes the network layer received.
 */
public final class ClientTotemTextureManager {

    private static final Map<UUID, class_2960> ACTIVE = new ConcurrentHashMap<>();

    /** Decode PNG bytes and register (or replace) the texture for this player. */
    public static void setSkin(UUID playerId, byte[] pngData) {
        class_310 client = class_310.method_1551();
        class_2960 textureId = class_2960.method_60655("mango-totem", "dynamic_totem_" + playerId);

        try {
            class_1011 image = class_1011.method_49277(pngData);
            // VERIFY: DynamicTexture's constructor shape has changed across
            // versions (some take just NativeImage, some take a debug-label
            // supplier too). If this line doesn't compile, check
            // DynamicTexture's constructors via genSources and adjust.
            class_1043 texture = new class_1043(() -> "mango-totem totem for " + playerId, image);
            // VERIFY: TextureManager's registration method name (register vs
            // registerTexture) via genSources if this doesn't compile.
            client.method_1531().method_4616(textureId, texture);
            ACTIVE.put(playerId, textureId);
        } catch (IOException e) {
            // Corrupt / not actually a PNG -- ignore rather than crash the game.
        }
    }

    public static byte[] applyEnchantedStyle(byte[] pngData, int color) {
        try (class_1011 image = class_1011.method_49277(pngData)) {
            int red = color & 0xFF;
            int green = color >> 8 & 0xFF;
            int blue = color >> 16 & 0xFF;

            for (int y = 0; y < image.method_4323(); y++) {
                for (int x = 0; x < image.method_4307(); x++) {
                    int pixel = image.method_61940(x, y);
                    int alpha = pixel >>> 24;
                    if (alpha == 0 || (x + y) % 8 >= 2) {
                        continue;
                    }

                    int oldRed = pixel & 0xFF;
                    int oldGreen = pixel >> 8 & 0xFF;
                    int oldBlue = pixel >> 16 & 0xFF;
                    int newRed = oldRed + (red - oldRed) * 3 / 5;
                    int newGreen = oldGreen + (green - oldGreen) * 3 / 5;
                    int newBlue = oldBlue + (blue - oldBlue) * 3 / 5;
                    image.method_61941(x, y, alpha << 24 | newBlue << 16 | newGreen << 8 | newRed);
                }
            }

            Path output = Files.createTempFile("mango-totem", ".png");
            image.method_4314(output);
            byte[] result = Files.readAllBytes(output);
            Files.deleteIfExists(output);
            return result;
        } catch (IOException e) {
            return pngData;
        }
    }

    public static void clearSkin(UUID playerId) {
        class_2960 textureId = ACTIVE.remove(playerId);
        if (textureId != null) {
            // VERIFY: method to release/free a registered texture (release
            // vs destroyTexture) via genSources if this doesn't compile.
            class_310.method_1551().method_1531().method_4615(textureId);
        }
    }

    /** @return the registered texture Identifier for this player, or null if they have no custom totem. */
    public static class_2960 getSkin(UUID playerId) {
        return ACTIVE.get(playerId);
    }

    private ClientTotemTextureManager() {}
}
