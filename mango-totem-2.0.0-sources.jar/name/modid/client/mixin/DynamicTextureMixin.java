package name.modid.client.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import net.minecraft.class_1043;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1043.class)
public class DynamicTextureMixin {
    @Inject(method = "<init>", at = @At("RETURN"))
    private void mango$useLinearFiltering(CallbackInfo callbackInfo) {
        ((AbstractTextureAccessor) this).mango$setSampler(RenderSystem.getSamplerCache().method_75297(FilterMode.LINEAR));
    }
}