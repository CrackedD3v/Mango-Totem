package name.modid.client.mixin;

import name.modid.client.ClientTotemTextureManager;
import name.modid.client.TotemRenderStateRegistry;
import net.minecraft.class_10442;
import net.minecraft.class_10444;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_10442.class)
public class ItemModelResolverMixin {
    @Inject(method = "updateForLiving", at = @At("TAIL"))
    private void mango$rememberTotemSkin(class_10444 state, class_1799 stack,
                                          class_811 displayContext, class_1309 holder,
                                          CallbackInfo callbackInfo) {
        if (stack.method_31574(class_1802.field_8288)) {
            TotemRenderStateRegistry.remember(state, ClientTotemTextureManager.getSkin(holder.method_5667()));
        }
    }
}