package name.modid.client.mixin;

import name.modid.client.TotemRenderStateRegistry;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(targets = "net.minecraft.client.renderer.item.ItemStackRenderState$LayerRenderState")
public abstract class ItemLayerRenderStateMixin {
    @Shadow @Final
    private class_10444 this$0;

    @Shadow
    private class_1921 renderType;

    @Inject(method = "submit", at = @At("HEAD"))
    private void mango$usePlayerTexture(class_4587 poseStack, class_11659 submitNodeCollector,
                                       int i, int j, int k, CallbackInfo callbackInfo) {
        class_2960 skin = TotemRenderStateRegistry.get(this$0);
        if (skin != null) {
            this.renderType = class_12249.method_76000(skin);
        }
    }
}