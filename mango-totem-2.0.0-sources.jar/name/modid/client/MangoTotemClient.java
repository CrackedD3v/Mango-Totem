package name.modid.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import name.modid.client.gui.SkinSelectScreen;
import name.modid.network.SelectSkinC2SPayload;
import name.modid.network.SkinUpdateS2CPayload;

import java.util.UUID;

public class MangoTotemClient implements ClientModInitializer {

    /** This client's own current selection, so we render it for ourselves too (inventory, hand, etc). */
    public static byte[] localSkinData = null;
    public static int enchantedColor = 0xFFFF00;

    private static class_304 openMenuKey;

    @Override
    public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(SkinUpdateS2CPayload.TYPE, (payload, context) ->
                context.client().execute(() -> {
                    UUID playerId = payload.playerId();
                    byte[] data = payload.pngData();
                    if (data.length == 0) {
                        ClientTotemTextureManager.clearSkin(playerId);
                    } else {
                        ClientTotemTextureManager.setSkin(playerId, data);
                    }
                })
        );

        // Unbound by default -- players set it themselves in Controls > Totem Swap.
        openMenuKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.mango-totem.open_menu",
            class_3675.class_307.field_1668,
            class_3675.field_16237.method_1444(),
            class_304.class_11900.method_74698(class_2960.method_60655("mango-totem", "category"))
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new SkinSelectScreen());
                }
            }
        });
    }

    /** Call this when the player picks a resource pack's totem texture, or null/empty to clear it. */
    public static void selectSkin(byte[] pngData) {
        localSkinData = (pngData == null || pngData.length == 0)
            ? null
            : ClientTotemTextureManager.applyEnchantedStyle(pngData, enchantedColor);

        if (localSkinData != null) {
            UUID selfId = class_310.method_1551().field_1724.method_5667();
            ClientTotemTextureManager.setSkin(selfId, localSkinData);
        }

        ClientPlayNetworking.send(new SelectSkinC2SPayload(localSkinData == null ? new byte[0] : localSkinData));
    }

    public static void setEnchantedColor(int color) {
        enchantedColor = color;
    }
}
