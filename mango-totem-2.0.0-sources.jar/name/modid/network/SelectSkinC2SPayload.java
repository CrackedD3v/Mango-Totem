package name.modid.network;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Sent client -> server with the raw PNG bytes of the texture the player
 * picked (extracted from one of their installed resource packs). An empty
 * byte array means "clear my custom totem, go back to vanilla".
 */
public record SelectSkinC2SPayload(byte[] pngData) implements class_8710 {

    /** Hard cap so nobody can push a huge file and clog the network. */
    public static final int MAX_BYTES = 256 * 1024; // 256 KB

    public static final class_8710.class_9154<SelectSkinC2SPayload> TYPE =
            new class_8710.class_9154<>(class_2960.method_60655("mango-totem", "select_skin"));

    public static final class_9139<class_2540, SelectSkinC2SPayload> STREAM_CODEC =
            class_9139.method_56434(
                    class_9135.field_48987, SelectSkinC2SPayload::pngData,
                    SelectSkinC2SPayload::new
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
