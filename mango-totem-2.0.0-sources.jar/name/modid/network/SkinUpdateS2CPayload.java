package name.modid.network;

import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_4844;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Sent server -> client(s): "this player's totem texture is now these PNG
 * bytes" (or empty bytes = they cleared it / back to vanilla).
 */
public record SkinUpdateS2CPayload(UUID playerId, byte[] pngData) implements class_8710 {

    public static final class_8710.class_9154<SkinUpdateS2CPayload> TYPE =
            new class_8710.class_9154<>(class_2960.method_60655("mango-totem", "skin_update"));

    public static final class_9139<class_2540, SkinUpdateS2CPayload> STREAM_CODEC =
            class_9139.method_56435(
                    class_4844.field_48453, SkinUpdateS2CPayload::playerId,
                    class_9135.field_48987, SkinUpdateS2CPayload::pngData,
                    SkinUpdateS2CPayload::new
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
