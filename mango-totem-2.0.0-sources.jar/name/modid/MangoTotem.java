package name.modid;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_3222;
import name.modid.network.SelectSkinC2SPayload;
import name.modid.network.SkinUpdateS2CPayload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class MangoTotem implements ModInitializer {

    public static final String MOD_ID = "mango-totem";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** Server-side source of truth: player UUID -> their totem PNG bytes (absent = vanilla). */
    public static final Map<UUID, byte[]> playerSkins = new ConcurrentHashMap<>();

    /**
     * A PNG can be bigger than vanilla's normal packet size limit, so these
     * are registered as "large" payloads -- Fabric's packet splitter
     * breaks them up automatically on the wire and reassembles them on the
     * other end.
     */
    private static final int MAX_PAYLOAD_BYTES = SelectSkinC2SPayload.MAX_BYTES + 1024;

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playC2S().registerLarge(
                SelectSkinC2SPayload.TYPE, SelectSkinC2SPayload.STREAM_CODEC, MAX_PAYLOAD_BYTES);
        PayloadTypeRegistry.playS2C().registerLarge(
                SkinUpdateS2CPayload.TYPE, SkinUpdateS2CPayload.STREAM_CODEC, MAX_PAYLOAD_BYTES);

        ServerPlayNetworking.registerGlobalReceiver(SelectSkinC2SPayload.TYPE, (payload, context) -> {
            class_3222 player = context.player();
            byte[] data = payload.pngData();

            if (data.length > SelectSkinC2SPayload.MAX_BYTES) {
                return; // ignore oversized submissions rather than crash or relay them
            }

            context.server().execute(() -> {
                if (data.length == 0) {
                    playerSkins.remove(player.method_5667());
                } else {
                    playerSkins.put(player.method_5667(), data);
                }

                SkinUpdateS2CPayload update = new SkinUpdateS2CPayload(player.method_5667(), data);
                for (class_3222 other : context.server().method_3760().method_14571()) {
                    if (ServerPlayNetworking.canSend(other, SkinUpdateS2CPayload.TYPE)) {
                        ServerPlayNetworking.send(other, update);
                    }
                }
            });
        });

        // New player joined -> send them everyone's current totem texture.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            if (!ServerPlayNetworking.canSend(handler.field_14140, SkinUpdateS2CPayload.TYPE)) {
                return; // vanilla / non-modded client, nothing to send
            }
            for (Map.Entry<UUID, byte[]> entry : playerSkins.entrySet()) {
                ServerPlayNetworking.send(handler.field_14140,
                        new SkinUpdateS2CPayload(entry.getKey(), entry.getValue()));
            }
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) ->
                playerSkins.remove(handler.field_14140.method_5667()));
    }
}
